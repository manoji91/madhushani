package project2;


import java.text.AttributedCharacterIterator.Attribute;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
public class myClass {
	public static void main(String[] args) {
		
		attributeclass attributeclass= new attributeclass();
		
        // declaration and instantiation of objects/variables
        WebDriver driver = new FirefoxDriver();
        String baseUrl = attributeclass.baseurl;
        // launch Firefox and direct it to the Base URL       
        driver.get(baseUrl);
        driver.manage().window().maximize();
        
        // Select �Rent� from the first drop down
        driver.findElement(By.xpath("//div[@id='rui-sel-search-channel']")).click();
        driver.findElement(By.xpath("//li[text()='"+attributeclass.firstdropdown+"']")).click();
                   
        //Enter �Melbourne City� in the next text box        
        String value = "Melbourne City";
        driver.findElement(By.xpath("//input[@id='where']")).sendKeys(attributeclass.textbox);
        driver.findElement(By.xpath("//input[@id='where']")).sendKeys(Keys.DOWN);
        driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
        driver.findElement(By.xpath("//input[@id='where']")).sendKeys(Keys.TAB);
        driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
        
        //Select  �Apartment & Unit� from �All Property Types�
        driver.findElement(By.xpath("//div[@id='rui-sel-rui-property-type-select-id']")).click();
        driver.findElement(By.xpath("//span[contains(text(),'"+attributeclass.AllPropertyTypes+"')]/..//span[@class='rui-checkbox-hide']")).click();
  	   	
               
        //Select �Min beds� = �Studio�
        driver.findElement(By.xpath("//div[@id='rui-sel-rui-min-beds-select-id']")).click();
        driver.findElement(By.xpath("//li[text()='Studio']")).click();
    
       //Select �Max beds� = �2 beds�
        driver.findElement(By.xpath("//div[@id='rui-sel-rui-max-beds-select-id']")).click();
        driver.findElement(By.xpath("//div[@id='rui-sel-rui-max-beds-select-id']/..//li[text()='2 Beds']")).click();
              
        // Select �Min Price pw� = �$200pw�
        driver.findElement(By.xpath("//div[@id='rui-sel-rui-min-price-select-id']")).click();
        driver.findElement(By.xpath("//li[text()='$200pw']")).click();
        

        //  Select �Max Price pw� =�$400pw�
         driver.findElement(By.xpath("//div[@id='rui-sel-rui-max-price-select-id']")).click();
         driver.findElement(By.xpath("//div[@id='rui-sel-rui-max-price-select-id']/..//li[text()='$400pw']")).click();
            
            
         // Select �Available Date� = �Avail. Now� 
        driver.findElement(By.xpath("//div[@id='rui-sel-rui-available-before-id']")).click();
        driver.findElement(By.xpath("//li[text()='Avail. now']")).click();
    
        // Click on search
        driver.findElement(By.className("rui-search-button")).click();
        // Print first search result label.
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("First search result is : "+driver.findElement(By.xpath("//a[@rel='listingName']")).getAttribute("text"));
        //Select the first Apartment/Unit from the search results
        driver.findElement(By.xpath("//a[@rel='listingName']")).click();
        System.out.println("Test Pass");
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");        
        
        //close Firefox
        driver.close();

        // exit the program explicitly
        System.exit(0);
    }

}
