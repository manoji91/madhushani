package project2;

public class attributeclass {
	
	String baseurl= "http://www.realestate.com.au";
	String firstdropdown = "Rent";
	String textbox = "Melbourne City";
	String AllPropertyTypes= "Apartment & Unit";
	String Minbeds= "Studio";
	String Maxbeds= "2 Beds";
	String MinPricepw= "$200pw";
	String MaxPricepw= "$400pw";
	String AvailableDate= "Avail. now";
	

}
