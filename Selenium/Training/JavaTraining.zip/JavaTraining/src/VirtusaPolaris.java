
public interface VirtusaPolaris {

}
