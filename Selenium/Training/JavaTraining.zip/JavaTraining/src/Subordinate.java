
public class Subordinate extends Employee {
    public Subordinate(){
    	super();
    	System.out.println("This is Constructor");
    }
    
}
